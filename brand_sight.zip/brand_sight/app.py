###############imports##########################
import pandas as pd
from dashboard_src import app,db
from flask import render_template, redirect, request, url_for, flash,abort, session
from flask_login import login_user,login_required,logout_user, current_user
from dashboard_src.models import User
from dashboard_src.forms import LoginForm, RegistrationForm, InfoForm,InfoForm2, PivotForm, CreativeForm, CreativeForm2
from werkzeug.security import generate_password_hash, check_password_hash


##############File_play##################
df = pd.read_excel("value.xlsx")
cf=pd.read_excel("units.xlsx")
company_options = list(df["COMPANY"].unique())
pass_list= list(zip(company_options,company_options))

######################Views################################

@app.route('/',methods=['GET','POST'])
def login():

    form = LoginForm()
    if form.validate_on_submit():

        user = User.query.filter_by(email=form.email.data).first()

        if user.check_password(form.password.data) and user is not None:


            login_user(user)
            flash('Logged in successfully.')
            next = request.args.get('next')
            if next == None or not next[0]=='/':
                next = url_for('dashboard')

            return redirect(next)
    return render_template('login.html', form=form)

@app.route('/register',methods=['GET','POST'])
def register():
        check = current_user.user_rank
        if  check in 'admin':

            form = RegistrationForm()

            if form.validate_on_submit():
                user = User(email=form.email.data,
                            username=form.username.data,
                            client_nm=form.client_nm.data,
                            user_rank=form.user_rank.data,
                            password=form.password.data)

                db.session.add(user)
                db.session.commit()
                flash('Thanks for registering! Now you can login!')
                return redirect(url_for('login'))
            return render_template('register.html', form=form)
        else:
            return redirect(url_for('login'))

#########incase of loosing data base ###################
########Uncomment this area & comment###################
#########the above given registration code##############
#    form = RegistrationForm()
#    if form.validate_on_submit():
#        user = User(email=form.email.data,
#                    username=form.username.data,
#                    client_nm=form.client_nm.data,
#                    user_rank=form.user_rank.data,
#                    password=form.password.data)
#
#        db.session.add(user)
#        db.session.commit()
#        flash('Thanks for registering! Now you can login!')
#        return redirect(url_for('login'))
#    return render_template('register.html', form=form)
#######################################################################
@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You logged out!')
    return redirect(url_for('login'))


@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
    invalid_submit=0
    form = InfoForm()
    if form.validate_on_submit():
        df = pd.read_excel("value.xlsx")
        cf=pd.read_excel("units.xlsx")
        company_data = form.company.data
        med_data=form.med.data
        if company_data==[]:
            df1=df.copy()
            df2=cf.copy()
        else:
            df1=df[df["COMPANY"].isin(company_data)]
            df2=cf[cf["COMPANY"].isin(company_data)]
        if med_data==[]:
            df3=df1.copy()
        else:
            df3=df1[df1["MEDTYPE"].isin(med_data)]
         #####1st error condition
        if df3.empty:
            df3=df.copy()

        else:
            df3=df3
        count=int(df3.count()[0])
        session["count"]=count
        matv=int(df3["MAT"].sum())
        matv="{:,}".format(matv)
        matv="₹"+matv+ "Mn"
        session["matv"]=matv
        matu=int(df3["MAT Units"].sum())
        matu=matu*1000
        matu="{:,}".format(matu)
        session["matu"]=matu
        matv=int(df3["MAT"].sum())
        matv=int(matv*1000000)
        matu=int(df3["MAT Units"].sum())
        #second error
        if matu==0:
            matv=int(df["MAT"].sum())
            matv=int(matv*1000000)
            matu=int(df["MAT Units"].sum())
            matu=int(matu*1000)
            vpu=int(matv/matu)
            vpu="{:,}".format(vpu)
            vpu="₹"+vpu
            session["vpu"]=vpu
        else:
            matv=int(df3["MAT"].sum())
            matv=int(matv*1000000)
            matu=int(df3["MAT Units"].sum())
            matu=int(matu*1000)
            vpu=int(matv/matu)
            vpu="{:,}".format(vpu)
            vpu="₹"+vpu
            session["vpu"]=vpu

        pv = pd.pivot_table(df3, index=['COMPANY','Type','MEDTYPE'], values=['MAT','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'], aggfunc=sum, fill_value=0)
        pv1=pd.pivot_table(df2,index=['COMPANY'],values=['MAT','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'], aggfunc=sum, fill_value=0)
        pv.reset_index(inplace=True)
        x=list(pv["COMPANY"])
        y=list(pv["MAT"])
        z=list(pv1["MAT"])
        month=list(pv.columns)
        Month=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
        data=pd.DataFrame(Month,columns=["Month"])
        data["sort"]=pd.to_datetime(data.Month,format='%b')
        data.sort_values("sort",inplace=True)
        data.drop("sort",inplace=True,axis=1)
        month=list(data["Month"])
        value=[]
        for i in month:
            s=pv[i].sum()
            value.append(s)
        pv3=pd.pivot_table(pv, index=["Type"], values=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'], aggfunc=sum, fill_value=0)
        types=list(pv3.index)
        val_sum=list((pv3.sum(axis=1)))
        val_sum=[int(i) for i in val_sum]

        value=[int(i) for i in value]
        sum_sum=sum(val_sum)
        pct=[(i/sum_sum)*100 for i in val_sum]
        pct=[round(i,2) for i in pct]
        month_wise=list(pv3.sum(axis=0))
        month_wise=[int(i) for i in month_wise]
        pv3.reset_index(inplace=True)
        if len(list(pv3["Type"].unique()))==2:
            india=(pv3[pv3["Type"]=="Indian"])
            mnc=(pv3[pv3["Type"]=="MNC"])
            india=india.T
            mnc=mnc.T
            india=india.iloc[1:]
            mnc=mnc.iloc[1:]
            india=india[0]
            mnc=mnc[1]
            india=list(india)
            mnc=list(mnc)
            india=[int(i) for i in india]
            mnc=[int(i) for i in mnc]
            k=list(zip(india,month_wise))
            l=list(zip(mnc,month_wise))
            india_pct=[(i/j)*100 for (i,j) in k]
            mnc_pct=[(i/j)*100 for (i,j) in l]
            india_pct=[round(i,2) for i in india_pct]
            mnc_pct=[round(i,2) for i in mnc_pct]
        else:
            if list(pv3["Type"])==["Indian"]:

                    india=pv3[pv3["Type"]=="Indian"]
                    india=india.T
                    india=india.iloc[1:]
                    india=india[0]
                    india=[int(i) for i in india]
                    month_wise=[1 if x==0 else x for x in month_wise]
                    k=list(zip(india,month_wise))

                    india_pct=[(i/j)*100 for (i,j) in k]
                    india_pct=[round(i,2) for i in india_pct]
                    mnc_pct=[]
            else:

                    mnc=pv3[pv3["Type"]=="MNC"]
                    mnc=mnc.T
                    mnc=mnc.iloc[1:]
                    mnc=mnc[0]
                    mnc=[int(i) for i in mnc]
                    month_wise=[1 if x==0 else x for x in month_wise]
                    l=list(zip(mnc,month_wise))
                    mnc_pct=[(i/j)*100 for (i,j) in l]

                    mnc_pct=[round(i,2) for i in mnc_pct]
                    india_pct=[]
        pv4=pd.pivot_table(pv, index=["MEDTYPE"], values=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'], aggfunc=sum, fill_value=0)
        sum_medtype=list(pv4.sum(axis=1))
        med_type=list(pv4.index)
        a=list(pv4.sum(axis=1))
        a=[int(i) for i in a]
        b=list(pv4.columns)
        i=0
        p=[]
        while i<len(a):
            k={"y":a[i],'quarters':[{'x':b[0],'y':int(pv4[b[0]][i])},
                                    {'x':b[1],'y':int(pv4[b[1]][i])},
                                    {'x':b[2],'y':int(pv4[b[2]][i])},
                                    {'x':b[3],'y':int(pv4[b[3]][i])},
                                    {'x':b[4],'y':int(pv4[b[4]][i])},
                                    {'x':b[5],'y':int(pv4[b[6]][i])},
                                    {'x':b[7],'y':int(pv4[b[8]][i])},
                                    {'x':b[9],'y':int(pv4[b[9]][i])},
                                    {'x':b[10],'y':int(pv4[b[10]][i])},
                                    {'x':b[11],'y':int(pv4[b[11]][i])}]}
            p.append(k)
            i=i+1
        colors = ['#008FFB', '#00E396', '#FEB019','#FF4560']
        item=pv4.index
        i=0
        q=[]
        while i<len(a):
            l={
                'x': item[i],
                'y': p[i]["y"],
                'color': colors[i],
                'quarters': p[i]['quarters']
            }
            q.append(l)
            i=i+1


        session['Company'] = company_data
        session["mat"]=y
        session["units"]=z
        session["month"]=month
        session["value"]=value
        session["types"]=types
        session["val_sum"]=pct
        session["sum_sum"]=sum_sum
        session["india_pct"]=india_pct
        session["mnc_pct"]=mnc_pct
        session["sum_medtype"]=sum_medtype
        session["medtype"]=med_type
        session["p"]=p
        session["q"]=q
    else:
        df = pd.read_excel("value.xlsx")
        cf=pd.read_excel("units.xlsx")
        company_data=list(df["COMPANY"].unique())
        med_data=list(df["MEDTYPE"].unique())
        df1=df[df["COMPANY"].isin(company_data)]
        df3=df1[df1["MEDTYPE"].isin(med_data)]
        df2=cf[cf["COMPANY"].isin(company_data)]
        count=int(df3.count()[0])
        session["count"]=count
        matv=int(df3["MAT"].sum())
        matv="{:,}".format(matv)
        matv="₹"+matv+ "Mn"
        session["matv"]=matv
        matu=int(df3["MAT Units"].sum())
        matu=matu*1000
        matu="{:,}".format(matu)
        session["matu"]=matu
        matv=int(df3["MAT"].sum())
        matv=int(matv*1000000)
        matu=int(df3["MAT Units"].sum())
        matu=int(matu*1000)
        vpu=int(matv/matu)
        vpu="{:,}".format(vpu)
        vpu="₹"+vpu
        session["vpu"]=vpu

        pv = pd.pivot_table(df3, index=['COMPANY','Type','MEDTYPE'], values=['MAT','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'], aggfunc=sum, fill_value=0)
        pv1=pd.pivot_table(df2,index=['COMPANY'],values=['MAT','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'], aggfunc=sum, fill_value=0)
        pv.reset_index(inplace=True)
        x=list(pv["COMPANY"])
        y=list(pv["MAT"])
        z=list(pv1["MAT"])
        month=list(pv.columns)
        Month=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
        data=pd.DataFrame(Month,columns=["Month"])
        data["sort"]=pd.to_datetime(data.Month,format='%b')
        data.sort_values("sort",inplace=True)
        data.drop("sort",inplace=True,axis=1)
        month=list(data["Month"])
        value=[]
        for i in month:
            s=pv[i].sum()
            value.append(s)
        pv3=pd.pivot_table(pv, index=["Type"], values=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'], aggfunc=sum, fill_value=0)
        types=list(pv3.index)
        val_sum=list((pv3.sum(axis=1)))
        val_sum=[int(i) for i in val_sum]

        value=[int(i) for i in value]
        sum_sum=sum(val_sum)
        pct=[(i/sum_sum)*100 for i in val_sum]
        pct=[round(i,2) for i in pct]
        month_wise=list(pv3.sum(axis=0))
        month_wise=[int(i) for i in month_wise]
        pv3.reset_index(inplace=True)
        if len(list(pv3["Type"].unique()))==2:
            india=(pv3[pv3["Type"]=="Indian"])
            mnc=(pv3[pv3["Type"]=="MNC"])
            india=india.T
            mnc=mnc.T
            india=india.iloc[1:]
            mnc=mnc.iloc[1:]
            india=india[0]
            mnc=mnc[1]
            india=list(india)
            mnc=list(mnc)
            india=[int(i) for i in india]
            mnc=[int(i) for i in mnc]
            k=list(zip(india,month_wise))
            l=list(zip(mnc,month_wise))
            india_pct=[(i/j)*100 for (i,j) in k]
            mnc_pct=[(i/j)*100 for (i,j) in l]
            india_pct=[round(i,2) for i in india_pct]
            mnc_pct=[round(i,2) for i in mnc_pct]
        else:
            if list(pv3["Type"])==["Indian"]:

                    india=pv3[pv3["Type"]=="Indian"]
                    india=india.T
                    india=india.iloc[1:]
                    india=india[0]
                    india=[int(i) for i in india]
                    k=list(zip(india,month_wise))
                    india_pct=[(i/j)*100 for (i,j) in k]
                    india_pct=[round(i,2) for i in india_pct]
                    mnc_pct=[]
            else:

                    mnc=pv3[pv3["Type"]=="MNC"]
                    mnc=mnc.T
                    mnc=mnc.iloc[1:]
                    mnc=mnc[0]
                    mnc=[int(i) for i in mnc]
                    l=list(zip(mnc,month_wise))
                    mnc_pct=[(i/j)*100 for (i,j) in l]
                    mnc_pct=[round(i,2) for i in mnc_pct]
                    india_pct=[]
        pv4=pd.pivot_table(pv, index=["MEDTYPE"], values=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'], aggfunc=sum, fill_value=0)
        sum_medtype=list(pv4.sum(axis=1))
        med_type=list(pv4.index)
        a=list(pv4.sum(axis=1))
        a=[int(i) for i in a]
        b=list(pv4.columns)
        i=0
        p=[]
        while i<len(a):
            k={"y":a[i],'quarters':[{'x':b[0],'y':int(pv4[b[0]][i])},
                                    {'x':b[1],'y':int(pv4[b[1]][i])},
                                    {'x':b[2],'y':int(pv4[b[2]][i])},
                                    {'x':b[3],'y':int(pv4[b[3]][i])},
                                    {'x':b[4],'y':int(pv4[b[4]][i])},
                                    {'x':b[5],'y':int(pv4[b[6]][i])},
                                    {'x':b[7],'y':int(pv4[b[8]][i])},
                                    {'x':b[9],'y':int(pv4[b[9]][i])},
                                    {'x':b[10],'y':int(pv4[b[10]][i])},
                                    {'x':b[11],'y':int(pv4[b[11]][i])}]}
            p.append(k)
            i=i+1
        colors = ['#008FFB', '#00E396', '#FEB019','#FF4560']
        item=pv4.index
        i=0
        q=[]
        while i<len(a):
            l={
                'x': item[i],
                'y': p[i]["y"],
                'color': colors[i],
                'quarters': p[i]['quarters']
            }
            q.append(l)
            i=i+1


        session['Company'] = company_data
        session["mat"]=y
        session["units"]=z
        session["month"]=month
        session["value"]=value
        session["types"]=types
        session["val_sum"]=pct
        session["sum_sum"]=sum_sum
        session["india_pct"]=india_pct
        session["mnc_pct"]=mnc_pct
        session["sum_medtype"]=sum_medtype
        session["medtype"]=med_type
        session["p"]=p
        session["q"]=q




    return render_template('main.html', form=form)
@app.route('/dashboard2', methods=['GET', 'POST'])
def dashboard2():

    form = InfoForm2()
    if form.validate_on_submit():
        onco=pd.read_excel("onco.xlsx")
        nephro=pd.read_excel("Nephro.xlsx")
        bc=pd.read_excel("BC.xlsx")
        lc=pd.read_excel("LC.xlsx")
        lungc=pd.read_excel("lungc.xlsx")
        account_data = form.account.data
        if account_data==[]:
            onco1=onco.copy()
            nephro1=nephro.copy()
            bc1=bc.copy()
            lc1=lc.copy()
            lungc1=lungc.copy()

        else:
            onco1=onco[onco["Account Name"].isin(account_data)]
            nephro1=nephro[nephro["Account Name"].isin(account_data)]
            bc1=bc[bc["Account Name"].isin(account_data)]
            lc1=lc[lc["Account Name"].isin(account_data)]
            lungc1=lungc[lungc["Account Name"].isin(account_data)]
        onco1.dropna(inplace=True)
        nephro1.dropna(inplace=True)

        oncohos=list(onco1["Account Name"])
        onconum=list(onco1["Onco"])
        onconum=[int(i) for i in onconum]
        nephos=list(nephro1["Account Name"])
        nepnum=list(nephro1["Nephrology"])
        nepnum=[int(i) for i in nepnum]

        lclab=list(lc1.columns)
        bclab=list(bc1["Account Name"])
        lclabel=list(lc1["Account Name"])
        lung=list(lc1["Total Lung"])
        lung=[int(i) for i in lung]
        oral=list(lc1["Oral"])
        oral=[int(i) for i in oral]
        rectal=list(lc1["Rectal"])
        rectal=[int(i) for i in rectal]
        breast=list(lc1["Breast"])
        breast=[int(i) for i in breast]

        lclab.remove("Account Name")
        lung_sum=int(lc1["Total Lung"].sum())

        oral_sum=int(lc1["Oral"].sum())

        rectal_sum=int(lc1["Rectal"].sum())

        breast_sum=int(lc1["Breast"].sum())

        onc_split=[lung_sum,oral_sum,rectal_sum,breast_sum]
        ebc=list(bc1["early Breast Cancer"])
        ebc=[int(i) for i in ebc]
        mbc=list(bc1["metastatic Breast cancer"])
        mbc=[int(i) for i in mbc]
        lungclab=list(lungc1["Account Name"])
        lungtot=list(lungc1["Total Lung"])
        lungtot=[int(i) for i in lungtot]
        lungsc=list(lungc1["SCLC"])
        lungsc=[int(i) for i in lungsc]
        lungn=list(lungc1["NSCLC"])
        breast_sum="{:,}".format(breast_sum)
        lung_sum="{:,}".format(lung_sum)
        oral_sum="{:,}".format(oral_sum)
        rectal_sum="{:,}".format(rectal_sum)

        session["lung_sum"]=lung_sum
        session["oral_sum"]=oral_sum
        session["rectal_sum"]=rectal_sum
        session["breast_sum"]=breast_sum
        session["lclabel"]=lclabel
        session["lung"]=lung
        session["oral"]=oral
        session["rectal"]=rectal
        session["breast"]=breast
        session["lungclab"]=lungclab
        session["lungtot"]=lungtot
        session["lungsc"]=lungsc
        session["lungn"]=lungn
        session["oncohos"]=oncohos
        session["onconum"]=onconum
        session["nephos"]=nephos
        session["nepnum"]=nepnum
        session["lclab"]=lclab
        session["bclab"]=bclab
        session["onc_split"]=onc_split
        session["ebc"]=ebc
        session["mbc"]=mbc


    else:
        af = pd.read_excel("accountprofiles.xlsx")
        onco=pd.read_excel("onco.xlsx")
        nephro=pd.read_excel("Nephro.xlsx")
        bc=pd.read_excel("BC.xlsx")
        lc=pd.read_excel("LC.xlsx")
        lungc=pd.read_excel("lungc.xlsx")
        account_data = list(af["Account Name"].unique())
        if account_data==[]:
            onco1=onco.copy()
            nephro1=nephro.copy()
            bc1=bc.copy()
            lc1=lc.copy()
            lungc1=lungc.copy()

        else:
            onco1=onco[onco["Account Name"].isin(account_data)]
            nephro1=nephro[nephro["Account Name"].isin(account_data)]
            bc1=bc[bc["Account Name"].isin(account_data)]
            lc1=lc[lc["Account Name"].isin(account_data)]
            lungc1=lungc[lungc["Account Name"].isin(account_data)]


        oncohos=list(onco1["Account Name"])
        onconum=list(onco1["Onco"])
        onconum=[int(i) for i in onconum]
        nephos=list(nephro1["Account Name"])
        nepnum=list(nephro1["Nephrology"])
        nepnum=[int(i) for i in nepnum]

        lclab=list(lc1.columns)
        bclab=list(bc1["Account Name"])
        lclabel=list(lc1["Account Name"])
        lung=list(lc1["Total Lung"])
        lung=[int(i) for i in lung]
        oral=list(lc1["Oral"])
        oral=[int(i) for i in oral]
        rectal=list(lc1["Rectal"])
        rectal=[int(i) for i in rectal]
        breast=list(lc1["Breast"])
        breast=[int(i) for i in breast]

        lclab.remove("Account Name")
        lung_sum=int(lc1["Total Lung"].sum())
        oral_sum=int(lc1["Oral"].sum())
        rectal_sum=int(lc1["Rectal"].sum())
        breast_sum=int(lc1["Breast"].sum())
        onc_split=[lung_sum,oral_sum,rectal_sum,breast_sum]
        breast_sum="{:,}".format(breast_sum)
        lung_sum="{:,}".format(lung_sum)
        oral_sum="{:,}".format(oral_sum)
        rectal_sum="{:,}".format(rectal_sum)
        ebc=list(bc1["early Breast Cancer"])
        ebc=[int(i) for i in ebc]
        mbc=list(bc1["metastatic Breast cancer"])
        mbc=[int(i) for i in mbc]
        lungclab=list(lungc1["Account Name"])
        lungtot=list(lungc1["Total Lung"])
        lungtot=[int(i) for i in lungtot]
        lungsc=list(lungc1["SCLC"])
        lungsc=[int(i) for i in lungsc]
        lungn=list(lungc1["NSCLC"])
        lungn=[int(i) for i in lungn]
        session["lung_sum"]=lung_sum
        session["oral_sum"]=oral_sum
        session["rectal_sum"]=rectal_sum
        session["breast_sum"]=breast_sum
        session["lclabel"]=lclabel
        session["lung"]=lung
        session["oral"]=oral
        session["rectal"]=rectal
        session["breast"]=breast
        session["lungclab"]=lungclab
        session["lungtot"]=lungtot
        session["lungsc"]=lungsc
        session["lungn"]=lungn
        session["oncohos"]=oncohos
        session["onconum"]=onconum
        session["nephos"]=nephos
        session["nepnum"]=nepnum
        session["lclab"]=lclab
        session["bclab"]=bclab
        session["onc_split"]=onc_split
        session["ebc"]=ebc
        session["mbc"]=mbc



    return render_template('Main2.html', form=form)

@app.route('/pivot',methods=['GET','POST'])
def pivot():
    form = PivotForm()
    if form.validate_on_submit():
        company_data = form.company.data
        med_data=form.med.data
        if company_data==[]:
            df1=df.copy()
            df2=cf.copy(0)
        else:
            df1=df[df["COMPANY"].isin(company_data)]
            df2=cf[cf["COMPANY"].isin(company_data)]
        if med_data==[]:
            df3=df1.copy()
        else:
            df3=df1[df1["MEDTYPE"].isin(med_data)]
        pv = pd.pivot_table(df3, index=['BRANDS','COMPANY','Type'], values=['MAT','MAT Units'], aggfunc=sum, fill_value=0)
        pv.rename(columns={'MAT': 'MAT(Mn)'},inplace=True)
        pv.reset_index(inplace=True)

        ll=list(pv.columns)
        l1=list(pv.iloc[:,0])
        l2=list(pv.iloc[:,1])
        l3=list(pv.iloc[:,2])
        l4=list(pv.iloc[:,3])
        l5=list(pv.iloc[:,4])
        l4=[int(i) for i in l4]
        l5=[int(i) for i in l5]
        l4=[format(i,',d') for i in l4]
        l5=[format(i,',d') for i in l5]
        l4=["₹"+str(i) for i in l4]
        session['pivot']=list(zip(l1,l2,l3,l4,l5))

    else:
        company_data=list(df["COMPANY"].unique())
        med_data=list(df["MEDTYPE"].unique())
        df1=df[df["COMPANY"].isin(company_data)]
        df3=df1[df1["MEDTYPE"].isin(med_data)]
        pv = pd.pivot_table(df3, index=['BRANDS','COMPANY','Type'], values=['MAT','MAT Units'], aggfunc=sum, fill_value=0)
        pv.rename(columns={'MAT': 'MAT(Mn)'},inplace=True)
        pv.reset_index(inplace=True)

        ll=list(pv.columns)
        l1=list(pv.iloc[:,0])
        l2=list(pv.iloc[:,1])
        l3=list(pv.iloc[:,2])
        l4=list(pv.iloc[:,3])
        l5=list(pv.iloc[:,4])
        l4=[int(i) for i in l4]
        l5=[int(i) for i in l5]
        l4=[format(i,',d') for i in l4]
        l5=[format(i,',d') for i in l5]
        l4=["₹"+str(i) for i in l4]
        session['pivot']=list(zip(l1,l2,l3,l4,l5))




    return render_template('pivot.html',ll=ll,form=form)


@app.route('/creatives',methods=['GET','POST'])
@login_required
def creatives():
    form01 = CreativeForm()
    form02 = CreativeForm2()
    if form01.validate_on_submit():
        return "Submitted"
    if form02.validate_on_submit():
        return "Submitted02"

    return render_template('creative.html',form02=form02,form01=form01)


##########################views#######################


if __name__ == '__main__':
    app.run(debug=True)
