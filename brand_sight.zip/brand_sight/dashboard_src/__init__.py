import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_login import LoginManager

login_manager = LoginManager()

app = Flask(__name__)
app.static_folder= r'/Users/atomik/Downloads/to_abhishek_13/exl_dashboard0.8/dashboard_src/templates/static'
app.config['SECRET_KEY'] = 'f86a615306a42af8539aeb74368872e15bd2d4ff6c8ed4c4af77e6f0643c7a10'
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI']='sqlite:///'+os.path.join(basedir, 'data.sqlite')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
migrate=Migrate(app,db)

login_manager.init_app(app)
login_manager.login_view = 'login'
